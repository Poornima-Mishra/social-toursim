"""Train ML models and generate analytics visuals for Tourism Analytics System."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "dataset"
MODEL_DIR = BASE_DIR / "models"
CHART_DIR = BASE_DIR / "static" / "charts"
MODEL_DIR.mkdir(exist_ok=True)
CHART_DIR.mkdir(parents=True, exist_ok=True)


def build_training_frame() -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / "destinations.csv")
    df = df.drop_duplicates().copy()
    df["estimated_cost"] = df["estimated_cost"].fillna(df["estimated_cost"].median())
    df["avg_rating"] = df["avg_rating"].fillna(df["avg_rating"].mean())
    df["popularity_score"] = df["popularity_score"].fillna(df["popularity_score"].median())
    df["preferred_activity"] = df["top_activities"].fillna("Culture").str.split("|").str[0]
    df["budget_numeric"] = df["estimated_cost"] + 3000
    df["season"] = df["best_season"].replace({"All Season": "Winter"})
    return df


def train() -> dict:
    df = build_training_frame()
    feature_cols = ["budget_numeric", "travel_type", "season", "preferred_activity", "estimated_cost", "avg_rating", "popularity_score"]
    X = df[feature_cols]
    y = df["recommended_label"].astype(int)

    numeric_features = ["budget_numeric", "estimated_cost", "avg_rating", "popularity_score"]
    categorical_features = ["travel_type", "season", "preferred_activity"]
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_features),
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
        ]
    )
    models = {
        "Random Forest": RandomForestClassifier(n_estimators=180, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42),
        "KNN": KNeighborsClassifier(n_neighbors=9),
    }
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    results = {}
    best_name = None
    best_pipeline = None
    best_f1 = -1.0
    for name, model in models.items():
        pipeline = Pipeline(steps=[("preprocess", preprocessor), ("model", model)])
        pipeline.fit(X_train, y_train)
        pred = pipeline.predict(X_test)
        metrics = {
            "accuracy": round(accuracy_score(y_test, pred), 4),
            "precision": round(precision_score(y_test, pred, zero_division=0), 4),
            "recall": round(recall_score(y_test, pred, zero_division=0), 4),
            "f1_score": round(f1_score(y_test, pred, zero_division=0), 4),
        }
        results[name] = metrics
        if metrics["f1_score"] > best_f1:
            best_name = name
            best_pipeline = pipeline
            best_f1 = metrics["f1_score"]

    joblib.dump(best_pipeline, MODEL_DIR / "recommendation_model.pkl")
    joblib.dump(best_pipeline.named_steps["preprocess"], MODEL_DIR / "scaler.pkl")
    (MODEL_DIR / "model_metrics.json").write_text(json.dumps({"best_model": best_name, "models": results}, indent=2), encoding="utf-8")
    return {"best_model": best_name, "models": results}


def create_charts() -> None:
    analytics = pd.read_csv(DATA_DIR / "tourism_analytics.csv")
    destinations = pd.read_csv(DATA_DIR / "destinations.csv")

    sns.set_theme(style="whitegrid")
    top = analytics.groupby("destination", as_index=False)["visitor_count"].sum().sort_values("visitor_count", ascending=False).head(10)
    plt.figure(figsize=(12, 6))
    sns.barplot(data=top, y="destination", x="visitor_count", palette="viridis")
    plt.title("Most Visited Destinations")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "most_visited_destinations.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 5))
    order = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    trend = analytics.groupby("month", as_index=False)["visitor_count"].sum()
    trend["month"] = pd.Categorical(trend["month"], categories=order, ordered=True)
    trend = trend.sort_values("month")
    sns.lineplot(data=trend, x="month", y="visitor_count", marker="o")
    plt.xticks(rotation=45)
    plt.title("Seasonal Tourism Trends")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "seasonal_tourism_trends.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 7))
    numeric = destinations[["estimated_cost", "avg_rating", "popularity_score", "recommended_label"]]
    sns.heatmap(numeric.corr(), annot=True, cmap="mako")
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "correlation_heatmap.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 5))
    sns.histplot(destinations["estimated_cost"], bins=30, kde=True, color="#0ea5e9")
    plt.title("Destination Estimated Budget Distribution")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "budget_histogram.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 5))
    sns.boxplot(data=analytics, x="season", y="avg_spending", palette="Set2")
    plt.title("Average Tourist Spending by Season")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "spending_boxplot.png", dpi=160)
    plt.close()


if __name__ == "__main__":
    print(json.dumps(train(), indent=2))
    create_charts()
    print("Training completed. Model, scaler, metrics and charts generated.")
