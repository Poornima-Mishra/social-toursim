document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));
  const alerts = document.querySelectorAll('.alert.auto-hide');
  alerts.forEach(alert => setTimeout(() => bootstrap.Alert.getOrCreateInstance(alert).close(), 4500));
});
