"""Regenerates the synthetic 1000+ record tourism datasets.

The repository already includes generated CSV files. This script is intentionally kept
as a reproducibility hook for evaluators. Run from the project root after installing
requirements if you want to regenerate datasets with your own logic.
"""
from pathlib import Path
import runpy

# The build_tourism_system.py script at repository root contains the deterministic
# dataset-generation logic used for this submission.
ROOT_SCRIPT = Path(__file__).resolve().parents[1] / "build_tourism_system.py"
if ROOT_SCRIPT.exists():
    runpy.run_path(str(ROOT_SCRIPT))
else:
    raise SystemExit("Dataset generator source not found. Use the included CSV datasets directly.")
