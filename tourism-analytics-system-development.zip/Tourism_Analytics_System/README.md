# Tourism Analytics System using Data Science, Machine Learning, and Web Development

A professional final-year major project for BCA/B.Tech evaluation. The system helps travelers plan trips intelligently by recommending destinations, hotels, restaurants, routes, budgets, weather insights and personalized day-wise itineraries.

## Tech Stack

- Frontend: HTML5, CSS3, JavaScript, Bootstrap 5
- Backend: Python, Flask
- Database: SQLite
- Data Science / ML: Pandas, NumPy, Scikit-Learn, Matplotlib, Seaborn
- Deployment: Render, Gunicorn

## Core Features

1. User registration, login and logout with password hashing.
2. Authenticated dashboard with popular destinations, weather summary, budget summary and recent recommendation history.
3. ML-based destination recommendation using budget, travel type, season and activities.
4. Hotel recommendation by budget, city, rating and type.
5. Restaurant recommendation by destination, food preference and budget.
6. Tourism analytics dashboard with Chart.js plus Matplotlib/Seaborn chart generation.
7. Weather prediction from dataset records.
8. Budget planner for accommodation, food, travel and local activity costs.
9. Route optimization using Dijkstra shortest path algorithm.
10. Personalized travel itinerary generator.

## Dataset Files

All datasets are stored in `dataset/` and contain 1000+ records each:

- `destinations.csv`
- `hotels.csv`
- `restaurants.csv`
- `weather.csv`
- `tourism_analytics.csv`

## Machine Learning Workflow

`train_model.py` implements:

- Data cleaning and duplicate removal
- Missing value handling
- Feature engineering
- Encoding categorical variables with OneHotEncoder
- Scaling numeric variables with StandardScaler
- EDA charts: heatmap, histogram and boxplot
- Model training: Random Forest, Decision Tree and KNN
- Evaluation: Accuracy, Precision, Recall and F1 Score
- Best model persistence to `models/recommendation_model.pkl`

## Installation

```bash
cd Tourism_Analytics_System
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
python app.py
```

Open: `http://127.0.0.1:5000`

## Default Usage

1. Register a new account.
2. Login.
3. Open Destination Recommendation and submit preferences.
4. Explore hotels, restaurants, analytics, weather, budget, route and itinerary modules.

## Render Deployment

This project includes `Procfile` and `render.yaml`.

Manual Render setup:

- Build command: `pip install -r requirements.txt && python train_model.py`
- Start command: `gunicorn app:app`
- Add environment variable: `SECRET_KEY`

## Folder Structure

```text
Tourism_Analytics_System/
├── app.py
├── requirements.txt
├── README.md
├── generate_datasets.py
├── train_model.py
├── Procfile
├── render.yaml
├── dataset/
├── models/
├── notebooks/
├── static/
├── templates/
├── database/
└── docs/
```

## Project Report Ready Notes

Detailed report and PPT outlines are available in `docs/project_report_outline.md` and `docs/ppt_content_outline.md`.
