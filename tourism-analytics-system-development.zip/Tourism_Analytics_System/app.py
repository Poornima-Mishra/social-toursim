"""Tourism Analytics System - Flask + SQLite + Machine Learning.

This application supports authentication, destination/hotel/restaurant recommendations,
weather lookup, analytics dashboards, route optimization, budget planning and itinerary
creation. It uses CSV datasets and can optionally load the trained scikit-learn model
created by train_model.py.
"""
from __future__ import annotations

import csv
import heapq
import json
import os
import sqlite3
from collections import Counter, defaultdict
from functools import wraps
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from flask import Flask, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "dataset"
DB_PATH = BASE_DIR / "database" / "tourism.db"
MODEL_PATH = BASE_DIR / "models" / "recommendation_model.pkl"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "tourism-analytics-development-key")
app.config["DATABASE"] = str(DB_PATH)


@app.template_filter("inr")
def inr(value: Any) -> str:
    try:
        amount = int(float(value))
    except (TypeError, ValueError):
        amount = 0
    return "₹{:,.0f}".format(amount)


def read_csv(filename: str) -> List[Dict[str, str]]:
    with (DATA_DIR / filename).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def get_db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS recommendation_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                preference_json TEXT NOT NULL,
                result_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
            """
        )


def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login to access this page.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped_view


def current_user() -> sqlite3.Row | None:
    if "user_id" not in session:
        return None
    with get_db() as conn:
        return conn.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()


def unique_by_name(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = set()
    output = []
    for row in rows:
        name = str(row.get("name") or row.get("destination") or row.get("city"))
        if name.lower() in seen:
            continue
        seen.add(name.lower())
        output.append(row)
    return output


def try_ml_score(row: Dict[str, str], budget: int, travel_type: str, season: str, activity: str) -> float | None:
    if not MODEL_PATH.exists():
        return None
    try:
        import joblib  # type: ignore
        import pandas as pd  # type: ignore

        model = joblib.load(MODEL_PATH)
        if not hasattr(model, "predict_proba"):
            return None
        frame = pd.DataFrame([
            {
                "budget_numeric": budget,
                "travel_type": travel_type,
                "season": season,
                "preferred_activity": activity,
                "estimated_cost": float(row.get("estimated_cost", 0)),
                "avg_rating": float(row.get("avg_rating", 0)),
                "popularity_score": float(row.get("popularity_score", 0)),
            }
        ])
        return float(model.predict_proba(frame)[0][1] * 100)
    except Exception:
        return None


def destination_score(row: Dict[str, str], prefs: Dict[str, Any]) -> float:
    budget = int(prefs.get("budget") or 0)
    travel_type = prefs.get("travel_type", "Family")
    season = prefs.get("season", "Winter")
    activities = [a.lower() for a in prefs.get("activities", [])]
    preferred_activity = activities[0].title() if activities else "Culture"

    estimated = float(row.get("estimated_cost", 0))
    rating = float(row.get("avg_rating", 0))
    popularity = float(row.get("popularity_score", 0))
    row_activities = row.get("top_activities", "").lower()

    score = 0.0
    if budget:
        budget_fit = max(0, 35 - abs(estimated - budget) / max(budget, 1) * 35)
        score += budget_fit
    if row.get("travel_type") == travel_type:
        score += 16
    if row.get("best_season") in {season, "All Season"}:
        score += 20
    score += min(18, sum(6 for activity in activities if activity in row_activities))
    score += rating * 4
    score += popularity * 0.15

    ml_score = try_ml_score(row, budget, travel_type, season, preferred_activity)
    if ml_score is not None:
        score = score * 0.60 + ml_score * 0.40
    return round(score, 2)


def recommend_destinations(prefs: Dict[str, Any], limit: int = 8) -> List[Dict[str, Any]]:
    scored = []
    for row in read_csv("destinations.csv"):
        row = dict(row)
        row["score"] = destination_score(row, prefs)
        scored.append(row)
    scored.sort(key=lambda item: item["score"], reverse=True)
    return unique_by_name(scored)[:limit]


def save_history(prefs: Dict[str, Any], results: List[Dict[str, Any]]) -> None:
    if "user_id" not in session:
        return
    clean_results = [
        {"name": r.get("name"), "estimated_cost": r.get("estimated_cost"), "score": r.get("score")}
        for r in results[:5]
    ]
    with get_db() as conn:
        conn.execute(
            "INSERT INTO recommendation_history (user_id, preference_json, result_json) VALUES (?, ?, ?)",
            (session["user_id"], json.dumps(prefs), json.dumps(clean_results)),
        )


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


@app.route("/")
def index():
    popular = sorted(read_csv("destinations.csv"), key=lambda r: int(r["popularity_score"]), reverse=True)
    return render_template("index.html", popular=unique_by_name(popular)[:6])


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Enter a valid name, email and password with at least 6 characters.", "danger")
            return render_template("register.html")
        try:
            with get_db() as conn:
                conn.execute(
                    "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
                    (name, email, generate_password_hash(password)),
                )
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email already registered.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    analytics = read_csv("tourism_analytics.csv")
    destinations = read_csv("destinations.csv")
    weather = read_csv("weather.csv")
    totals: Dict[str, int] = defaultdict(int)
    spend: List[int] = []
    for row in analytics:
        totals[row["destination"]] += int(row["visitor_count"])
        spend.append(int(row["avg_spending"]))
    popular_names = [name for name, _ in Counter(totals).most_common(6)]
    popular = [row for row in unique_by_name(sorted(destinations, key=lambda r: int(r["popularity_score"]), reverse=True)) if row["name"] in popular_names][:6]
    with get_db() as conn:
        history = conn.execute(
            "SELECT * FROM recommendation_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
            (session["user_id"],),
        ).fetchall()
    return render_template(
        "dashboard.html",
        popular=popular,
        weather=unique_by_name(weather)[:5],
        avg_spending=round(sum(spend) / len(spend)),
        history=history,
    )


@app.route("/recommendation", methods=["GET", "POST"])
@login_required
def recommendation():
    results = []
    prefs = {"budget": 25000, "travel_type": "Family", "season": "Winter", "activities": ["Culture"]}
    if request.method == "POST":
        prefs = {
            "budget": int(request.form.get("budget") or 25000),
            "travel_type": request.form.get("travel_type", "Family"),
            "season": request.form.get("season", "Winter"),
            "activities": request.form.getlist("activities") or [request.form.get("activity", "Culture")],
        }
        results = recommend_destinations(prefs)
        save_history(prefs, results)
        flash("ML-powered recommendations generated successfully.", "success")
    return render_template("recommendation.html", results=results, prefs=prefs)


@app.route("/hotel", methods=["GET", "POST"])
@login_required
def hotel():
    hotels = []
    if request.method == "POST":
        city = request.form.get("city", "").strip().lower()
        budget = int(request.form.get("budget") or 5000)
        rating = float(request.form.get("rating") or 3.5)
        hotel_type = request.form.get("hotel_type", "Any")
        rows = read_csv("hotels.csv")
        for row in rows:
            if city and city not in row["city"].lower():
                continue
            if hotel_type != "Any" and row["hotel_type"] != hotel_type:
                continue
            if int(row["price_per_night"]) <= budget and float(row["rating"]) >= rating:
                hotels.append(row)
        hotels = sorted(hotels, key=lambda r: (float(r["rating"]), -int(r["price_per_night"])), reverse=True)[:12]
        flash(f"Found {len(hotels)} matching hotels.", "info")
    return render_template("hotel.html", hotels=hotels, hotel_types=["Any", "Budget", "Standard", "Deluxe", "Resort", "Heritage", "Business"])


@app.route("/restaurant", methods=["GET", "POST"])
@login_required
def restaurant():
    restaurants = []
    if request.method == "POST":
        destination = request.form.get("destination", "").strip().lower()
        preference = request.form.get("food_preference", "Any")
        budget = int(request.form.get("budget") or 1000)
        for row in read_csv("restaurants.csv"):
            if destination and destination not in row["destination"].lower():
                continue
            if preference != "Any" and preference not in {row["food_preference"], row["cuisine"]}:
                continue
            if int(row["average_cost"]) <= budget:
                restaurants.append(row)
        restaurants = sorted(restaurants, key=lambda r: float(r["rating"]), reverse=True)[:12]
        flash(f"Found {len(restaurants)} restaurant suggestions.", "info")
    preferences = ["Any", "Vegetarian", "Non-Vegetarian", "Vegan", "Seafood", "Local Cuisine", "Multi Cuisine"]
    return render_template("restaurant.html", restaurants=restaurants, preferences=preferences)


@app.route("/analytics")
@login_required
def analytics():
    rows = read_csv("tourism_analytics.csv")
    visitor_totals: Dict[str, int] = defaultdict(int)
    spending_by_dest: Dict[str, List[int]] = defaultdict(list)
    month_totals: Dict[str, int] = defaultdict(int)
    activities = Counter()
    satisfaction: Dict[str, List[float]] = defaultdict(list)
    for row in rows:
        visitor_totals[row["destination"]] += int(row["visitor_count"])
        spending_by_dest[row["destination"]].append(int(row["avg_spending"]))
        month_totals[row["month"]] += int(row["visitor_count"])
        activities[row["popular_activity"]] += 1
        satisfaction[row["destination"]].append(float(row["satisfaction_score"]))
    top_dest = sorted(visitor_totals.items(), key=lambda x: x[1], reverse=True)[:8]
    top_spend = sorted(((k, round(sum(v) / len(v))) for k, v in spending_by_dest.items()), key=lambda x: x[1], reverse=True)[:8]
    sat = sorted(((k, round(sum(v) / len(v), 2)) for k, v in satisfaction.items()), key=lambda x: x[1], reverse=True)[:8]
    chart_data = {
        "destinations": top_dest,
        "spending": top_spend,
        "trends": [(m, month_totals.get(m, 0)) for m in ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]],
        "activities": activities.most_common(8),
        "satisfaction": sat,
    }
    chart_dir = BASE_DIR / "static" / "charts"
    chart_images = sorted([p.name for pattern in ("*.png", "*.svg") for p in chart_dir.glob(pattern)])
    return render_template("analytics.html", chart_data=chart_data, chart_json=json.dumps(chart_data), chart_images=chart_images)


@app.route("/weather", methods=["GET", "POST"])
@login_required
def weather():
    result = None
    if request.method == "POST":
        destination = request.form.get("destination", "").strip().lower()
        matches = [row for row in read_csv("weather.csv") if destination in row["destination"].lower()]
        if matches:
            avg_temp = round(sum(float(r["temperature"]) for r in matches) / len(matches), 1)
            avg_humidity = round(sum(int(r["humidity"]) for r in matches) / len(matches))
            condition = Counter(r["condition"] for r in matches).most_common(1)[0][0]
            result = {"destination": matches[0]["destination"], "temperature": avg_temp, "humidity": avg_humidity, "condition": condition, "samples": matches[:6]}
        else:
            flash("No weather data found for this destination.", "warning")
    return render_template("weather.html", result=result)


@app.route("/budget", methods=["GET", "POST"])
@login_required
def budget():
    plan = None
    if request.method == "POST":
        days = max(1, int(request.form.get("days") or 1))
        destination = request.form.get("destination", "Jaipur")
        hotel_type = request.form.get("hotel_type", "Standard")
        transport_type = request.form.get("transport_type", "Train")
        hotel_rates = {"Budget": 1400, "Standard": 2500, "Deluxe": 4300, "Resort": 6200, "Heritage": 7500, "Business": 5200}
        transport_rates = {"Bus": 1800, "Train": 2800, "Flight": 8500, "Car Rental": 5500}
        accommodation = hotel_rates.get(hotel_type, 2500) * days
        food = 950 * days
        travel = transport_rates.get(transport_type, 2800)
        local = 1200 * days
        plan = {"destination": destination, "days": days, "accommodation": accommodation, "food": food, "travel": travel, "local": local, "total": accommodation + food + travel + local}
    return render_template("budget.html", plan=plan, hotel_types=["Budget", "Standard", "Deluxe", "Resort", "Heritage", "Business"], transports=["Bus", "Train", "Flight", "Car Rental"])


ROUTE_GRAPH: Dict[str, Dict[str, int]] = {
    "Delhi": {"Jaipur": 281, "Agra": 233, "Rishikesh": 242, "Shimla": 343},
    "Jaipur": {"Delhi": 281, "Udaipur": 395, "Jaisalmer": 558, "Agra": 238},
    "Agra": {"Delhi": 233, "Jaipur": 238, "Varanasi": 610},
    "Varanasi": {"Agra": 610, "Kolkata": 680},
    "Kolkata": {"Varanasi": 680, "Darjeeling": 615, "Guwahati": 990},
    "Guwahati": {"Kolkata": 990, "Kaziranga": 193, "Meghalaya": 100},
    "Mumbai": {"Goa": 590, "Pune": 150, "Udaipur": 760},
    "Pune": {"Mumbai": 150, "Goa": 445, "Hyderabad": 560},
    "Goa": {"Mumbai": 590, "Pune": 445, "Bengaluru": 560},
    "Bengaluru": {"Goa": 560, "Mysuru": 145, "Ooty": 270, "Chennai": 350, "Hyderabad": 575},
    "Mysuru": {"Bengaluru": 145, "Coorg": 120, "Ooty": 125},
    "Chennai": {"Bengaluru": 350, "Pondicherry": 155, "Mahabalipuram": 60},
    "Kochi": {"Munnar": 130, "Kerala Backwaters": 55},
    "Munnar": {"Kochi": 130, "Coorg": 430},
    "Hyderabad": {"Pune": 560, "Bengaluru": 575, "Chennai": 625},
    "Udaipur": {"Jaipur": 395, "Mumbai": 760, "Rann of Kutch": 500},
    "Shimla": {"Delhi": 343, "Manali": 250},
    "Manali": {"Shimla": 250, "Leh Ladakh": 475},
}


def shortest_route(start: str, end: str) -> Tuple[List[str], int]:
    if start not in ROUTE_GRAPH or end not in ROUTE_GRAPH:
        return [], 0
    queue = [(0, start, [])]
    visited = set()
    while queue:
        distance, city, path = heapq.heappop(queue)
        if city in visited:
            continue
        path = path + [city]
        if city == end:
            return path, distance
        visited.add(city)
        for neighbor, edge in ROUTE_GRAPH.get(city, {}).items():
            if neighbor not in visited:
                heapq.heappush(queue, (distance + edge, neighbor, path))
    return [], 0


@app.route("/route", methods=["GET", "POST"])
@login_required
def route_optimizer():
    result = None
    cities = sorted(ROUTE_GRAPH.keys())
    if request.method == "POST":
        start = request.form.get("start", "Delhi")
        end = request.form.get("destination", "Jaipur")
        path, distance = shortest_route(start, end)
        if path:
            result = {"path": path, "distance": distance, "time": round(distance / 55, 1)}
        else:
            flash("Route data is not available for the selected cities.", "warning")
    return render_template("route.html", cities=cities, result=result)


@app.route("/itinerary", methods=["GET", "POST"])
@login_required
def itinerary():
    itinerary_days = []
    if request.method == "POST":
        destination = request.form.get("destination", "Jaipur")
        days = min(7, max(1, int(request.form.get("days") or 3)))
        destinations = [row for row in read_csv("destinations.csv") if destination.lower() in row["name"].lower()]
        base = destinations[0] if destinations else read_csv("destinations.csv")[0]
        attractions = base["attractions"].split("|")
        restaurants = [r for r in read_csv("restaurants.csv") if base["name"].lower() in r["destination"].lower()]
        hotels = [h for h in read_csv("hotels.csv") if base["name"].lower() in h["city"].lower()]
        for day in range(1, days + 1):
            itinerary_days.append({
                "day": day,
                "morning": attractions[(day - 1) % len(attractions)],
                "afternoon": attractions[day % len(attractions)],
                "evening": attractions[(day + 1) % len(attractions)],
                "food": restaurants[(day - 1) % len(restaurants)]["restaurant_name"] if restaurants else "Local food walk",
                "hotel": hotels[(day - 1) % len(hotels)]["hotel_name"] if hotels else "Recommended city hotel",
            })
        flash("Personalized itinerary generated.", "success")
    return render_template("itinerary.html", itinerary=itinerary_days)


@app.errorhandler(404)
def page_not_found(error):
    return render_template("error.html", message="The page you requested was not found."), 404


@app.errorhandler(500)
def server_error(error):
    return render_template("error.html", message="Something went wrong. Please try again."), 500


init_db()

if __name__ == "__main__":
    app.run(debug=True)
