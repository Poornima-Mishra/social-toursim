import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const modules = [
  "User Authentication",
  "ML Destination Recommendation",
  "Hotel Recommendation",
  "Restaurant Recommendation",
  "Tourism Analytics Dashboard",
  "Weather Prediction",
  "Budget Planner",
  "Route Optimization",
  "Personalized Itinerary",
  "Render Deployment Ready",
];

const datasetStats = [
  { label: "Destinations", value: "1200", detail: "season, travel type, activities, cost" },
  { label: "Hotels", value: "1200", detail: "city, type, rating, price, location" },
  { label: "Restaurants", value: "1200", detail: "cuisine, preference, budget, rating" },
  { label: "Weather", value: "1200", detail: "temperature, humidity, condition" },
  { label: "Analytics", value: "1200", detail: "visitors, spending, trends, satisfaction" },
];

const mlPipeline = [
  "Data cleaning and missing-value handling",
  "Categorical encoding and numeric scaling",
  "EDA with heatmap, histograms and boxplots",
  "Random Forest, Decision Tree and KNN training",
  "Accuracy, precision, recall and F1 comparison",
];

export default async function HomePage() {
  await db.execute(sql`select 1`);

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,#ccfbf1,transparent_32rem),radial-gradient(circle_at_top_right,#dbeafe,transparent_28rem),linear-gradient(135deg,#f8fafc,#ecfeff_52%,#fff7ed)] px-6 py-10 text-slate-950">
      <section className="mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-white/80 shadow-[0_30px_90px_rgba(15,23,42,0.16)] ring-1 ring-white/70 backdrop-blur">
        <div className="grid gap-8 bg-[linear-gradient(135deg,rgba(15,118,110,0.95),rgba(2,132,199,0.88)),radial-gradient(circle_at_80%_20%,rgba(251,191,36,0.75),transparent_10rem)] px-6 py-14 text-white md:px-12 lg:grid-cols-[1.15fr_0.85fr] lg:px-16 lg:py-20">
          <div>
            <p className="mb-4 inline-flex rounded-full bg-amber-300 px-4 py-2 text-sm font-bold uppercase tracking-[0.18em] text-teal-950">
              Final Year Major Project
            </p>
            <h1 className="max-w-4xl text-[clamp(2.5rem,6vw,5.5rem)] font-black leading-[0.95] tracking-[-0.06em]">
              Tourism Analytics System
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-cyan-50 md:text-xl">
              A complete Flask, SQLite, Bootstrap and Machine Learning project that helps travelers plan intelligent trips with destination, hotel, restaurant, weather, budget, route and itinerary recommendations.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <span className="rounded-full bg-white px-5 py-3 font-bold text-teal-800 shadow-lg">Python + Flask</span>
              <span className="rounded-full bg-white px-5 py-3 font-bold text-sky-800 shadow-lg">SQLite</span>
              <span className="rounded-full bg-white px-5 py-3 font-bold text-amber-700 shadow-lg">Scikit-Learn</span>
              <span className="rounded-full bg-white px-5 py-3 font-bold text-indigo-800 shadow-lg">Bootstrap 5</span>
            </div>
          </div>
          <div className="rounded-[1.6rem] bg-white/16 p-5 ring-1 ring-white/30 backdrop-blur">
            <p className="text-sm font-semibold uppercase tracking-[0.16em] text-cyan-100">Project package generated</p>
            <h2 className="mt-3 text-3xl font-black tracking-tight">Tourism_Analytics_System/</h2>
            <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
              {modules.slice(0, 8).map((item) => (
                <div key={item} className="rounded-2xl bg-white/90 px-4 py-3 font-semibold text-slate-800 shadow-sm">
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-8 px-6 py-10 md:px-12 lg:grid-cols-3 lg:px-16">
          <div className="rounded-[1.5rem] bg-slate-950 p-7 text-white shadow-2xl lg:col-span-1">
            <p className="text-sm font-bold uppercase tracking-[0.16em] text-cyan-300">Evaluation ready</p>
            <h2 className="mt-3 text-3xl font-black tracking-tight">Industry-level project deliverables</h2>
            <p className="mt-4 text-slate-300">
              Includes source code, database schema, generated datasets, training script, notebook, deployment config, README, report outline and PPT outline.
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:col-span-2">
            {modules.map((item) => (
              <div key={item} className="rounded-3xl border border-sky-100 bg-white p-5 shadow-sm">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-sky-500 text-lg font-black text-white">
                  ✓
                </div>
                <h3 className="font-bold text-slate-900">{item}</h3>
              </div>
            ))}
          </div>
        </div>

        <div className="border-y border-slate-100 bg-slate-50/80 px-6 py-10 md:px-12 lg:px-16">
          <div className="mb-6 flex flex-col justify-between gap-3 md:flex-row md:items-end">
            <div>
              <p className="font-bold uppercase tracking-[0.16em] text-teal-700">Datasets</p>
              <h2 className="text-3xl font-black tracking-tight">Five CSV datasets with 1000+ records each</h2>
            </div>
            <p className="max-w-xl text-slate-600">
              Deterministic synthetic datasets are stored under <span className="font-mono font-semibold">Tourism_Analytics_System/dataset</span> for repeatable evaluation.
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-5">
            {datasetStats.map((item) => (
              <div key={item.label} className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
                <p className="text-sm font-semibold text-slate-500">{item.label}</p>
                <p className="mt-2 text-4xl font-black text-teal-700">{item.value}</p>
                <p className="mt-2 text-sm text-slate-600">{item.detail}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid gap-8 px-6 py-10 md:px-12 lg:grid-cols-2 lg:px-16">
          <div className="rounded-[1.5rem] border border-teal-100 bg-white p-7 shadow-sm">
            <p className="font-bold uppercase tracking-[0.16em] text-teal-700">Machine Learning</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight">Recommendation model pipeline</h2>
            <ul className="mt-6 space-y-4">
              {mlPipeline.map((step) => (
                <li key={step} className="flex gap-3 text-slate-700">
                  <span className="mt-1 h-3 w-3 rounded-full bg-teal-500" />
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-[1.5rem] border border-amber-100 bg-gradient-to-br from-amber-50 to-orange-50 p-7 shadow-sm">
            <p className="font-bold uppercase tracking-[0.16em] text-amber-700">How to run</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight">Flask project commands</h2>
            <div className="mt-6 rounded-2xl bg-slate-950 p-5 font-mono text-sm leading-7 text-slate-100">
              <p>cd Tourism_Analytics_System</p>
              <p>python -m venv venv</p>
              <p>pip install -r requirements.txt</p>
              <p>python train_model.py</p>
              <p>python app.py</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
