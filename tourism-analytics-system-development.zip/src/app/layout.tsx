import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tourism Analytics System",
  description:
    "Final-year tourism analytics project with Flask, SQLite, ML recommendations, datasets, analytics, weather, budgets, routes and itineraries.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
