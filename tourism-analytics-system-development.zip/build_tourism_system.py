from pathlib import Path
import csv
import json
import pickle
import random
import sqlite3
import textwrap

ROOT = Path("Tourism_Analytics_System")
random.seed(42)

DIRS = [
    "dataset", "models", "notebooks", "static/css", "static/js", "static/images",
    "static/charts", "templates", "database", "docs"
]
for d in DIRS:
    (ROOT / d).mkdir(parents=True, exist_ok=True)


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(textwrap.dedent(content).lstrip(), encoding="utf-8")


cities = [
    ("Jaipur", "Rajasthan", "North", "Winter", "Family", "Forts|Palaces|Shopping|Culture", "Amber Fort|City Palace|Hawa Mahal|Nahargarh Fort", 18500, 4.7),
    ("Goa", "Goa", "West", "Winter", "Friends", "Beaches|Nightlife|Water Sports|Food", "Baga Beach|Fort Aguada|Dudhsagar Falls|Anjuna Market", 24500, 4.8),
    ("Manali", "Himachal Pradesh", "North", "Summer", "Couple", "Adventure|Mountains|Snow|Nature", "Solang Valley|Hadimba Temple|Rohtang Pass|Mall Road", 22000, 4.6),
    ("Kerala Backwaters", "Kerala", "South", "Winter", "Couple", "Nature|Boating|Ayurveda|Food", "Alleppey Houseboat|Kumarakom|Vembanad Lake|Marari Beach", 28000, 4.8),
    ("Varanasi", "Uttar Pradesh", "North", "Winter", "Solo", "Spiritual|Culture|Photography|Food", "Dashashwamedh Ghat|Kashi Vishwanath|Sarnath|Ganga Aarti", 14500, 4.5),
    ("Delhi", "Delhi", "North", "Winter", "Family", "History|Food|Shopping|Museums", "India Gate|Red Fort|Qutub Minar|Akshardham", 17000, 4.4),
    ("Mumbai", "Maharashtra", "West", "Monsoon", "Friends", "City Life|Food|Shopping|Beaches", "Gateway of India|Marine Drive|Elephanta Caves|Juhu Beach", 23000, 4.5),
    ("Bengaluru", "Karnataka", "South", "All Season", "Solo", "Technology|Food|Gardens|Nightlife", "Lalbagh|Cubbon Park|Bangalore Palace|UB City", 20000, 4.4),
    ("Mysuru", "Karnataka", "South", "Winter", "Family", "Palaces|Culture|Food|Gardens", "Mysore Palace|Brindavan Gardens|Chamundi Hills|St Philomena Church", 16000, 4.6),
    ("Ooty", "Tamil Nadu", "South", "Summer", "Family", "Hill Station|Nature|Tea Gardens|Boating", "Botanical Garden|Ooty Lake|Doddabetta Peak|Tea Museum", 19000, 4.5),
    ("Darjeeling", "West Bengal", "East", "Summer", "Couple", "Tea Gardens|Mountains|Toy Train|Nature", "Tiger Hill|Batasia Loop|Tea Estates|Peace Pagoda", 21000, 4.6),
    ("Agra", "Uttar Pradesh", "North", "Winter", "Couple", "Heritage|Photography|Food|History", "Taj Mahal|Agra Fort|Mehtab Bagh|Fatehpur Sikri", 15500, 4.7),
    ("Udaipur", "Rajasthan", "North", "Winter", "Couple", "Lakes|Palaces|Culture|Photography", "City Palace|Lake Pichola|Sajjangarh|Saheliyon Ki Bari", 24000, 4.8),
    ("Rishikesh", "Uttarakhand", "North", "Summer", "Friends", "Adventure|Spiritual|Yoga|Rafting", "Laxman Jhula|Triveni Ghat|River Rafting|Beatles Ashram", 17500, 4.5),
    ("Shimla", "Himachal Pradesh", "North", "Summer", "Family", "Mountains|Snow|Shopping|Heritage", "Mall Road|Jakhoo Temple|Kufri|Christ Church", 20000, 4.5),
    ("Pondicherry", "Puducherry", "South", "Winter", "Solo", "Beaches|French Colony|Food|Spiritual", "Promenade Beach|Auroville|White Town|Paradise Beach", 18500, 4.4),
    ("Kolkata", "West Bengal", "East", "Winter", "Family", "Culture|Food|Museums|History", "Victoria Memorial|Howrah Bridge|Dakshineswar|Park Street", 16500, 4.4),
    ("Hyderabad", "Telangana", "South", "Winter", "Family", "Food|Heritage|Shopping|Museums", "Charminar|Golconda Fort|Ramoji Film City|Hussain Sagar", 18000, 4.5),
    ("Amritsar", "Punjab", "North", "Winter", "Family", "Spiritual|Food|History|Culture", "Golden Temple|Wagah Border|Jallianwala Bagh|Partition Museum", 15000, 4.6),
    ("Andaman", "Andaman and Nicobar", "East", "Winter", "Couple", "Beaches|Scuba Diving|Nature|Water Sports", "Radhanagar Beach|Cellular Jail|Neil Island|Ross Island", 36000, 4.8),
    ("Leh Ladakh", "Ladakh", "North", "Summer", "Friends", "Adventure|Mountains|Biking|Photography", "Pangong Lake|Nubra Valley|Magnetic Hill|Shanti Stupa", 42000, 4.9),
    ("Sikkim", "Sikkim", "East", "Summer", "Family", "Mountains|Monasteries|Nature|Culture", "Tsomgo Lake|Rumtek Monastery|Nathula Pass|MG Marg", 30000, 4.7),
    ("Coorg", "Karnataka", "South", "Monsoon", "Couple", "Coffee|Nature|Waterfalls|Trekking", "Abbey Falls|Raja Seat|Coffee Estates|Dubare Camp", 22500, 4.6),
    ("Jaisalmer", "Rajasthan", "North", "Winter", "Friends", "Desert Safari|Forts|Culture|Camping", "Jaisalmer Fort|Sam Dunes|Patwon Ki Haveli|Gadisar Lake", 23000, 4.6),
    ("Hampi", "Karnataka", "South", "Winter", "Solo", "Heritage|Boulders|Photography|History", "Virupaksha Temple|Vijaya Vittala Temple|Lotus Mahal|Matanga Hill", 16500, 4.5),
    ("Meghalaya", "Meghalaya", "East", "Monsoon", "Friends", "Waterfalls|Caves|Nature|Trekking", "Cherrapunji|Living Root Bridges|Dawki|Mawsmai Cave", 28500, 4.7),
    ("Kochi", "Kerala", "South", "Winter", "Family", "Backwaters|Food|Heritage|Art", "Fort Kochi|Jew Town|Marine Drive|Chinese Fishing Nets", 19500, 4.5),
    ("Mahabalipuram", "Tamil Nadu", "South", "Winter", "Family", "Beaches|Temples|Heritage|Photography", "Shore Temple|Five Rathas|Arjuna Penance|Beach", 15500, 4.4),
    ("Munnar", "Kerala", "South", "Monsoon", "Couple", "Tea Gardens|Nature|Trekking|Wildlife", "Eravikulam Park|Tea Museum|Mattupetty Dam|Top Station", 23000, 4.7),
    ("Nainital", "Uttarakhand", "North", "Summer", "Family", "Lake|Boating|Mountains|Shopping", "Naini Lake|Snow View|Mall Road|Naina Devi Temple", 18500, 4.4),
    ("Auli", "Uttarakhand", "North", "Winter", "Friends", "Skiing|Snow|Adventure|Mountains", "Auli Ropeway|Gurso Bugyal|Joshimath|Artificial Lake", 27000, 4.6),
    ("Khajuraho", "Madhya Pradesh", "Central", "Winter", "Solo", "Temples|History|Culture|Photography", "Western Group Temples|Raneh Falls|Panna Park|Dance Festival", 16000, 4.3),
    ("Bhopal", "Madhya Pradesh", "Central", "Winter", "Family", "Lakes|Museums|Food|Heritage", "Upper Lake|Sanchi Stupa|Bhimbetka|Tribal Museum", 15000, 4.2),
    ("Kanyakumari", "Tamil Nadu", "South", "Winter", "Family", "Beaches|Spiritual|Sunrise|Culture", "Vivekananda Rock|Thiruvalluvar Statue|Sunset Point|Temple", 17000, 4.4),
    ("Pune", "Maharashtra", "West", "Monsoon", "Friends", "Food|Forts|Nightlife|Trekking", "Sinhagad Fort|Aga Khan Palace|Shaniwar Wada|Koregaon Park", 17000, 4.3),
    ("Chennai", "Tamil Nadu", "South", "Winter", "Family", "Beaches|Temples|Food|Museums", "Marina Beach|Kapaleeshwarar Temple|Fort St George|Mahabalipuram Day Trip", 17500, 4.3),
    ("Guwahati", "Assam", "East", "Winter", "Family", "River|Temples|Wildlife|Food", "Kamakhya Temple|Brahmaputra Cruise|Umananda|Pobitora", 18500, 4.3),
    ("Rann of Kutch", "Gujarat", "West", "Winter", "Friends", "Desert|Festival|Culture|Photography", "White Rann|Kala Dungar|Kutch Museum|Bhujodi", 26000, 4.6),
    ("Lakshadweep", "Lakshadweep", "South", "Winter", "Couple", "Beaches|Snorkeling|Islands|Water Sports", "Agatti|Bangaram|Kadmat|Marine Museum", 45000, 4.8),
    ("Kaziranga", "Assam", "East", "Winter", "Family", "Wildlife|Safari|Nature|Photography", "Kaziranga Safari|Orchid Park|Tea Garden|Brahmaputra View", 28000, 4.7),
]

hotel_types = ["Budget", "Standard", "Deluxe", "Resort", "Heritage", "Business"]
cuisines = ["North Indian", "South Indian", "Continental", "Chinese", "Seafood", "Italian", "Street Food", "Vegan", "Local Thali"]
food_preferences = ["Vegetarian", "Non-Vegetarian", "Vegan", "Seafood", "Local Cuisine", "Multi Cuisine"]
months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
season_by_month = {
    "December": "Winter", "January": "Winter", "February": "Winter",
    "March": "Summer", "April": "Summer", "May": "Summer", "June": "Summer",
    "July": "Monsoon", "August": "Monsoon", "September": "Monsoon",
    "October": "Winter", "November": "Winter",
}
weather_conditions = {
    "Winter": ["Clear", "Pleasant", "Cool", "Foggy"],
    "Summer": ["Sunny", "Warm", "Dry", "Partly Cloudy"],
    "Monsoon": ["Rainy", "Humid", "Cloudy", "Thunderstorms"],
    "All Season": ["Pleasant", "Partly Cloudy", "Clear"],
}

# destinations.csv
with (ROOT / "dataset/destinations.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=[
        "destination_id", "name", "state", "region", "best_season", "travel_type", "top_activities",
        "estimated_cost", "best_time_to_visit", "attractions", "avg_rating", "popularity_score", "recommended_label"
    ])
    writer.writeheader()
    for i in range(1, 1201):
        city = cities[(i - 1) % len(cities)]
        variation = random.randint(-2500, 4500)
        popularity = min(99, max(45, int(city[8] * 16 + random.randint(-8, 18))))
        writer.writerow({
            "destination_id": i,
            "name": city[0],
            "state": city[1],
            "region": city[2],
            "best_season": city[3],
            "travel_type": city[4],
            "top_activities": city[5],
            "estimated_cost": max(8000, city[7] + variation),
            "best_time_to_visit": f"{city[3]} season; ideal for {city[4].lower()} travelers",
            "attractions": city[6],
            "avg_rating": round(min(5, max(3.5, city[8] + random.uniform(-0.25, 0.25))), 1),
            "popularity_score": popularity,
            "recommended_label": 1 if popularity >= 72 and city[8] >= 4.4 else 0,
        })

# hotels.csv
with (ROOT / "dataset/hotels.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["hotel_id", "city", "hotel_name", "hotel_type", "rating", "price_per_night", "location"])
    writer.writeheader()
    for i in range(1, 1201):
        city = cities[(i - 1) % len(cities)][0]
        htype = random.choice(hotel_types)
        base = {"Budget": 1200, "Standard": 2200, "Deluxe": 3800, "Resort": 5200, "Heritage": 6400, "Business": 4500}[htype]
        writer.writerow({
            "hotel_id": i,
            "city": city,
            "hotel_name": f"{random.choice(['Grand', 'Royal', 'Blue', 'Green', 'Urban', 'Heritage', 'Vista', 'Lotus'])} {city} {random.choice(['Inn', 'Retreat', 'Suites', 'Palace', 'Resort', 'Stay'])}",
            "hotel_type": htype,
            "rating": round(random.uniform(3.2, 4.9), 1),
            "price_per_night": base + random.randint(-500, 1800),
            "location": random.choice(["City Center", "Near Railway Station", "Airport Road", "Tourist Zone", "Lake View", "Market Area", "Old Town"]),
        })

# restaurants.csv
with (ROOT / "dataset/restaurants.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["restaurant_id", "destination", "restaurant_name", "cuisine", "food_preference", "rating", "average_cost"])
    writer.writeheader()
    for i in range(1, 1201):
        city = cities[(i - 1) % len(cities)][0]
        cuisine = random.choice(cuisines)
        pref = random.choice(food_preferences)
        writer.writerow({
            "restaurant_id": i,
            "destination": city,
            "restaurant_name": f"{random.choice(['Spice', 'Saffron', 'Coastal', 'Urban', 'Heritage', 'Tandoor', 'Garden', 'Bistro'])} {random.choice(['Table', 'Cafe', 'Kitchen', 'House', 'Grill', 'Diner'])}",
            "cuisine": cuisine,
            "food_preference": pref,
            "rating": round(random.uniform(3.3, 4.9), 1),
            "average_cost": random.randint(250, 1800),
        })

# weather.csv
with (ROOT / "dataset/weather.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["weather_id", "destination", "month", "season", "temperature", "humidity", "condition"])
    writer.writeheader()
    for i in range(1, 1201):
        city = cities[(i - 1) % len(cities)]
        month = months[(i - 1) % 12]
        season = season_by_month[month]
        mountain = city[2] in ["North", "East"] and any(word in city[5] for word in ["Mountains", "Snow", "Tea"])
        beach = any(word in city[5] for word in ["Beaches", "Water Sports", "Islands"])
        temp_base = {"Winter": 18, "Summer": 31, "Monsoon": 26}[season]
        if mountain:
            temp_base -= random.randint(5, 12)
        if beach:
            temp_base += random.randint(1, 4)
        writer.writerow({
            "weather_id": i,
            "destination": city[0],
            "month": month,
            "season": season,
            "temperature": round(temp_base + random.uniform(-3.5, 3.5), 1),
            "humidity": random.randint(42, 92),
            "condition": random.choice(weather_conditions[season]),
        })

# tourism_analytics.csv
with (ROOT / "dataset/tourism_analytics.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=[
        "record_id", "destination", "month", "season", "visitor_count", "avg_spending", "popular_activity", "satisfaction_score", "travel_type"
    ])
    writer.writeheader()
    for i in range(1, 1201):
        city = cities[(i - 1) % len(cities)]
        month = random.choice(months)
        season = season_by_month[month]
        peak = 1.35 if season == city[3] or city[3] == "All Season" else 0.82
        activity = random.choice(city[5].split("|"))
        writer.writerow({
            "record_id": i,
            "destination": city[0],
            "month": month,
            "season": season,
            "visitor_count": int(random.randint(8500, 85000) * peak),
            "avg_spending": city[7] + random.randint(-4500, 6500),
            "popular_activity": activity,
            "satisfaction_score": round(min(5, max(3.2, city[8] + random.uniform(-0.35, 0.25))), 1),
            "travel_type": random.choice(["Solo", "Family", "Couple", "Friends"]),
        })

write("requirements.txt", """
Flask==3.0.3
Werkzeug==3.0.3
pandas==2.2.2
numpy==1.26.4
scikit-learn==1.5.1
matplotlib==3.9.0
seaborn==0.13.2
joblib==1.4.2
gunicorn==22.0.0
""")

write("Procfile", """
web: gunicorn app:app
""")

write("render.yaml", """
services:
  - type: web
    name: tourism-analytics-system
    env: python
    plan: free
    buildCommand: pip install -r requirements.txt && python train_model.py
    startCommand: gunicorn app:app
    envVars:
      - key: SECRET_KEY
        generateValue: true
""")

write("app.py", r'''
"""Tourism Analytics System - Flask + SQLite + Machine Learning.

This application supports authentication, destination/hotel/restaurant recommendations,
weather lookup, analytics dashboards, route optimization, budget planning and itinerary
creation. It uses CSV datasets and can optionally load the trained scikit-learn model
created by train_model.py.
"""
from __future__ import annotations

import csv
import heapq
import json
import os
import sqlite3
from collections import Counter, defaultdict
from functools import wraps
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from flask import Flask, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "dataset"
DB_PATH = BASE_DIR / "database" / "tourism.db"
MODEL_PATH = BASE_DIR / "models" / "recommendation_model.pkl"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "tourism-analytics-development-key")
app.config["DATABASE"] = str(DB_PATH)


@app.template_filter("inr")
def inr(value: Any) -> str:
    try:
        amount = int(float(value))
    except (TypeError, ValueError):
        amount = 0
    return "₹{:,.0f}".format(amount)


def read_csv(filename: str) -> List[Dict[str, str]]:
    with (DATA_DIR / filename).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def get_db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS recommendation_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                preference_json TEXT NOT NULL,
                result_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
            """
        )


def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login to access this page.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped_view


def current_user() -> sqlite3.Row | None:
    if "user_id" not in session:
        return None
    with get_db() as conn:
        return conn.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()


def unique_by_name(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = set()
    output = []
    for row in rows:
        name = str(row.get("name") or row.get("destination") or row.get("city"))
        if name.lower() in seen:
            continue
        seen.add(name.lower())
        output.append(row)
    return output


def try_ml_score(row: Dict[str, str], budget: int, travel_type: str, season: str, activity: str) -> float | None:
    if not MODEL_PATH.exists():
        return None
    try:
        import joblib  # type: ignore
        import pandas as pd  # type: ignore

        model = joblib.load(MODEL_PATH)
        if not hasattr(model, "predict_proba"):
            return None
        frame = pd.DataFrame([
            {
                "budget_numeric": budget,
                "travel_type": travel_type,
                "season": season,
                "preferred_activity": activity,
                "estimated_cost": float(row.get("estimated_cost", 0)),
                "avg_rating": float(row.get("avg_rating", 0)),
                "popularity_score": float(row.get("popularity_score", 0)),
            }
        ])
        return float(model.predict_proba(frame)[0][1] * 100)
    except Exception:
        return None


def destination_score(row: Dict[str, str], prefs: Dict[str, Any]) -> float:
    budget = int(prefs.get("budget") or 0)
    travel_type = prefs.get("travel_type", "Family")
    season = prefs.get("season", "Winter")
    activities = [a.lower() for a in prefs.get("activities", [])]
    preferred_activity = activities[0].title() if activities else "Culture"

    estimated = float(row.get("estimated_cost", 0))
    rating = float(row.get("avg_rating", 0))
    popularity = float(row.get("popularity_score", 0))
    row_activities = row.get("top_activities", "").lower()

    score = 0.0
    if budget:
        budget_fit = max(0, 35 - abs(estimated - budget) / max(budget, 1) * 35)
        score += budget_fit
    if row.get("travel_type") == travel_type:
        score += 16
    if row.get("best_season") in {season, "All Season"}:
        score += 20
    score += min(18, sum(6 for activity in activities if activity in row_activities))
    score += rating * 4
    score += popularity * 0.15

    ml_score = try_ml_score(row, budget, travel_type, season, preferred_activity)
    if ml_score is not None:
        score = score * 0.60 + ml_score * 0.40
    return round(score, 2)


def recommend_destinations(prefs: Dict[str, Any], limit: int = 8) -> List[Dict[str, Any]]:
    scored = []
    for row in read_csv("destinations.csv"):
        row = dict(row)
        row["score"] = destination_score(row, prefs)
        scored.append(row)
    scored.sort(key=lambda item: item["score"], reverse=True)
    return unique_by_name(scored)[:limit]


def save_history(prefs: Dict[str, Any], results: List[Dict[str, Any]]) -> None:
    if "user_id" not in session:
        return
    clean_results = [
        {"name": r.get("name"), "estimated_cost": r.get("estimated_cost"), "score": r.get("score")}
        for r in results[:5]
    ]
    with get_db() as conn:
        conn.execute(
            "INSERT INTO recommendation_history (user_id, preference_json, result_json) VALUES (?, ?, ?)",
            (session["user_id"], json.dumps(prefs), json.dumps(clean_results)),
        )


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


@app.route("/")
def index():
    popular = sorted(read_csv("destinations.csv"), key=lambda r: int(r["popularity_score"]), reverse=True)
    return render_template("index.html", popular=unique_by_name(popular)[:6])


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Enter a valid name, email and password with at least 6 characters.", "danger")
            return render_template("register.html")
        try:
            with get_db() as conn:
                conn.execute(
                    "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
                    (name, email, generate_password_hash(password)),
                )
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email already registered.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    analytics = read_csv("tourism_analytics.csv")
    destinations = read_csv("destinations.csv")
    weather = read_csv("weather.csv")
    totals: Dict[str, int] = defaultdict(int)
    spend: List[int] = []
    for row in analytics:
        totals[row["destination"]] += int(row["visitor_count"])
        spend.append(int(row["avg_spending"]))
    popular_names = [name for name, _ in Counter(totals).most_common(6)]
    popular = [row for row in unique_by_name(sorted(destinations, key=lambda r: int(r["popularity_score"]), reverse=True)) if row["name"] in popular_names][:6]
    with get_db() as conn:
        history = conn.execute(
            "SELECT * FROM recommendation_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
            (session["user_id"],),
        ).fetchall()
    return render_template(
        "dashboard.html",
        popular=popular,
        weather=unique_by_name(weather)[:5],
        avg_spending=round(sum(spend) / len(spend)),
        history=history,
    )


@app.route("/recommendation", methods=["GET", "POST"])
@login_required
def recommendation():
    results = []
    prefs = {"budget": 25000, "travel_type": "Family", "season": "Winter", "activities": ["Culture"]}
    if request.method == "POST":
        prefs = {
            "budget": int(request.form.get("budget") or 25000),
            "travel_type": request.form.get("travel_type", "Family"),
            "season": request.form.get("season", "Winter"),
            "activities": request.form.getlist("activities") or [request.form.get("activity", "Culture")],
        }
        results = recommend_destinations(prefs)
        save_history(prefs, results)
        flash("ML-powered recommendations generated successfully.", "success")
    return render_template("recommendation.html", results=results, prefs=prefs)


@app.route("/hotel", methods=["GET", "POST"])
@login_required
def hotel():
    hotels = []
    if request.method == "POST":
        city = request.form.get("city", "").strip().lower()
        budget = int(request.form.get("budget") or 5000)
        rating = float(request.form.get("rating") or 3.5)
        hotel_type = request.form.get("hotel_type", "Any")
        rows = read_csv("hotels.csv")
        for row in rows:
            if city and city not in row["city"].lower():
                continue
            if hotel_type != "Any" and row["hotel_type"] != hotel_type:
                continue
            if int(row["price_per_night"]) <= budget and float(row["rating"]) >= rating:
                hotels.append(row)
        hotels = sorted(hotels, key=lambda r: (float(r["rating"]), -int(r["price_per_night"])), reverse=True)[:12]
        flash(f"Found {len(hotels)} matching hotels.", "info")
    return render_template("hotel.html", hotels=hotels, hotel_types=["Any", "Budget", "Standard", "Deluxe", "Resort", "Heritage", "Business"])


@app.route("/restaurant", methods=["GET", "POST"])
@login_required
def restaurant():
    restaurants = []
    if request.method == "POST":
        destination = request.form.get("destination", "").strip().lower()
        preference = request.form.get("food_preference", "Any")
        budget = int(request.form.get("budget") or 1000)
        for row in read_csv("restaurants.csv"):
            if destination and destination not in row["destination"].lower():
                continue
            if preference != "Any" and preference not in {row["food_preference"], row["cuisine"]}:
                continue
            if int(row["average_cost"]) <= budget:
                restaurants.append(row)
        restaurants = sorted(restaurants, key=lambda r: float(r["rating"]), reverse=True)[:12]
        flash(f"Found {len(restaurants)} restaurant suggestions.", "info")
    preferences = ["Any", "Vegetarian", "Non-Vegetarian", "Vegan", "Seafood", "Local Cuisine", "Multi Cuisine"]
    return render_template("restaurant.html", restaurants=restaurants, preferences=preferences)


@app.route("/analytics")
@login_required
def analytics():
    rows = read_csv("tourism_analytics.csv")
    visitor_totals: Dict[str, int] = defaultdict(int)
    spending_by_dest: Dict[str, List[int]] = defaultdict(list)
    month_totals: Dict[str, int] = defaultdict(int)
    activities = Counter()
    satisfaction: Dict[str, List[float]] = defaultdict(list)
    for row in rows:
        visitor_totals[row["destination"]] += int(row["visitor_count"])
        spending_by_dest[row["destination"]].append(int(row["avg_spending"]))
        month_totals[row["month"]] += int(row["visitor_count"])
        activities[row["popular_activity"]] += 1
        satisfaction[row["destination"]].append(float(row["satisfaction_score"]))
    top_dest = sorted(visitor_totals.items(), key=lambda x: x[1], reverse=True)[:8]
    top_spend = sorted(((k, round(sum(v) / len(v))) for k, v in spending_by_dest.items()), key=lambda x: x[1], reverse=True)[:8]
    sat = sorted(((k, round(sum(v) / len(v), 2)) for k, v in satisfaction.items()), key=lambda x: x[1], reverse=True)[:8]
    chart_data = {
        "destinations": top_dest,
        "spending": top_spend,
        "trends": [(m, month_totals.get(m, 0)) for m in ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]],
        "activities": activities.most_common(8),
        "satisfaction": sat,
    }
    chart_dir = BASE_DIR / "static" / "charts"
    chart_images = sorted([p.name for pattern in ("*.png", "*.svg") for p in chart_dir.glob(pattern)])
    return render_template("analytics.html", chart_data=chart_data, chart_json=json.dumps(chart_data), chart_images=chart_images)


@app.route("/weather", methods=["GET", "POST"])
@login_required
def weather():
    result = None
    if request.method == "POST":
        destination = request.form.get("destination", "").strip().lower()
        matches = [row for row in read_csv("weather.csv") if destination in row["destination"].lower()]
        if matches:
            avg_temp = round(sum(float(r["temperature"]) for r in matches) / len(matches), 1)
            avg_humidity = round(sum(int(r["humidity"]) for r in matches) / len(matches))
            condition = Counter(r["condition"] for r in matches).most_common(1)[0][0]
            result = {"destination": matches[0]["destination"], "temperature": avg_temp, "humidity": avg_humidity, "condition": condition, "samples": matches[:6]}
        else:
            flash("No weather data found for this destination.", "warning")
    return render_template("weather.html", result=result)


@app.route("/budget", methods=["GET", "POST"])
@login_required
def budget():
    plan = None
    if request.method == "POST":
        days = max(1, int(request.form.get("days") or 1))
        destination = request.form.get("destination", "Jaipur")
        hotel_type = request.form.get("hotel_type", "Standard")
        transport_type = request.form.get("transport_type", "Train")
        hotel_rates = {"Budget": 1400, "Standard": 2500, "Deluxe": 4300, "Resort": 6200, "Heritage": 7500, "Business": 5200}
        transport_rates = {"Bus": 1800, "Train": 2800, "Flight": 8500, "Car Rental": 5500}
        accommodation = hotel_rates.get(hotel_type, 2500) * days
        food = 950 * days
        travel = transport_rates.get(transport_type, 2800)
        local = 1200 * days
        plan = {"destination": destination, "days": days, "accommodation": accommodation, "food": food, "travel": travel, "local": local, "total": accommodation + food + travel + local}
    return render_template("budget.html", plan=plan, hotel_types=["Budget", "Standard", "Deluxe", "Resort", "Heritage", "Business"], transports=["Bus", "Train", "Flight", "Car Rental"])


ROUTE_GRAPH: Dict[str, Dict[str, int]] = {
    "Delhi": {"Jaipur": 281, "Agra": 233, "Rishikesh": 242, "Shimla": 343},
    "Jaipur": {"Delhi": 281, "Udaipur": 395, "Jaisalmer": 558, "Agra": 238},
    "Agra": {"Delhi": 233, "Jaipur": 238, "Varanasi": 610},
    "Varanasi": {"Agra": 610, "Kolkata": 680},
    "Kolkata": {"Varanasi": 680, "Darjeeling": 615, "Guwahati": 990},
    "Guwahati": {"Kolkata": 990, "Kaziranga": 193, "Meghalaya": 100},
    "Mumbai": {"Goa": 590, "Pune": 150, "Udaipur": 760},
    "Pune": {"Mumbai": 150, "Goa": 445, "Hyderabad": 560},
    "Goa": {"Mumbai": 590, "Pune": 445, "Bengaluru": 560},
    "Bengaluru": {"Goa": 560, "Mysuru": 145, "Ooty": 270, "Chennai": 350, "Hyderabad": 575},
    "Mysuru": {"Bengaluru": 145, "Coorg": 120, "Ooty": 125},
    "Chennai": {"Bengaluru": 350, "Pondicherry": 155, "Mahabalipuram": 60},
    "Kochi": {"Munnar": 130, "Kerala Backwaters": 55},
    "Munnar": {"Kochi": 130, "Coorg": 430},
    "Hyderabad": {"Pune": 560, "Bengaluru": 575, "Chennai": 625},
    "Udaipur": {"Jaipur": 395, "Mumbai": 760, "Rann of Kutch": 500},
    "Shimla": {"Delhi": 343, "Manali": 250},
    "Manali": {"Shimla": 250, "Leh Ladakh": 475},
}


def shortest_route(start: str, end: str) -> Tuple[List[str], int]:
    if start not in ROUTE_GRAPH or end not in ROUTE_GRAPH:
        return [], 0
    queue = [(0, start, [])]
    visited = set()
    while queue:
        distance, city, path = heapq.heappop(queue)
        if city in visited:
            continue
        path = path + [city]
        if city == end:
            return path, distance
        visited.add(city)
        for neighbor, edge in ROUTE_GRAPH.get(city, {}).items():
            if neighbor not in visited:
                heapq.heappush(queue, (distance + edge, neighbor, path))
    return [], 0


@app.route("/route", methods=["GET", "POST"])
@login_required
def route_optimizer():
    result = None
    cities = sorted(ROUTE_GRAPH.keys())
    if request.method == "POST":
        start = request.form.get("start", "Delhi")
        end = request.form.get("destination", "Jaipur")
        path, distance = shortest_route(start, end)
        if path:
            result = {"path": path, "distance": distance, "time": round(distance / 55, 1)}
        else:
            flash("Route data is not available for the selected cities.", "warning")
    return render_template("route.html", cities=cities, result=result)


@app.route("/itinerary", methods=["GET", "POST"])
@login_required
def itinerary():
    itinerary_days = []
    if request.method == "POST":
        destination = request.form.get("destination", "Jaipur")
        days = min(7, max(1, int(request.form.get("days") or 3)))
        destinations = [row for row in read_csv("destinations.csv") if destination.lower() in row["name"].lower()]
        base = destinations[0] if destinations else read_csv("destinations.csv")[0]
        attractions = base["attractions"].split("|")
        restaurants = [r for r in read_csv("restaurants.csv") if base["name"].lower() in r["destination"].lower()]
        hotels = [h for h in read_csv("hotels.csv") if base["name"].lower() in h["city"].lower()]
        for day in range(1, days + 1):
            itinerary_days.append({
                "day": day,
                "morning": attractions[(day - 1) % len(attractions)],
                "afternoon": attractions[day % len(attractions)],
                "evening": attractions[(day + 1) % len(attractions)],
                "food": restaurants[(day - 1) % len(restaurants)]["restaurant_name"] if restaurants else "Local food walk",
                "hotel": hotels[(day - 1) % len(hotels)]["hotel_name"] if hotels else "Recommended city hotel",
            })
        flash("Personalized itinerary generated.", "success")
    return render_template("itinerary.html", itinerary=itinerary_days)


@app.errorhandler(404)
def page_not_found(error):
    return render_template("error.html", message="The page you requested was not found."), 404


@app.errorhandler(500)
def server_error(error):
    return render_template("error.html", message="Something went wrong. Please try again."), 500


init_db()

if __name__ == "__main__":
    app.run(debug=True)
''')

write("train_model.py", r'''
"""Train ML models and generate analytics visuals for Tourism Analytics System."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "dataset"
MODEL_DIR = BASE_DIR / "models"
CHART_DIR = BASE_DIR / "static" / "charts"
MODEL_DIR.mkdir(exist_ok=True)
CHART_DIR.mkdir(parents=True, exist_ok=True)


def build_training_frame() -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / "destinations.csv")
    df = df.drop_duplicates().copy()
    df["estimated_cost"] = df["estimated_cost"].fillna(df["estimated_cost"].median())
    df["avg_rating"] = df["avg_rating"].fillna(df["avg_rating"].mean())
    df["popularity_score"] = df["popularity_score"].fillna(df["popularity_score"].median())
    df["preferred_activity"] = df["top_activities"].fillna("Culture").str.split("|").str[0]
    df["budget_numeric"] = df["estimated_cost"] + 3000
    df["season"] = df["best_season"].replace({"All Season": "Winter"})
    return df


def train() -> dict:
    df = build_training_frame()
    feature_cols = ["budget_numeric", "travel_type", "season", "preferred_activity", "estimated_cost", "avg_rating", "popularity_score"]
    X = df[feature_cols]
    y = df["recommended_label"].astype(int)

    numeric_features = ["budget_numeric", "estimated_cost", "avg_rating", "popularity_score"]
    categorical_features = ["travel_type", "season", "preferred_activity"]
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_features),
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
        ]
    )
    models = {
        "Random Forest": RandomForestClassifier(n_estimators=180, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42),
        "KNN": KNeighborsClassifier(n_neighbors=9),
    }
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    results = {}
    best_name = None
    best_pipeline = None
    best_f1 = -1.0
    for name, model in models.items():
        pipeline = Pipeline(steps=[("preprocess", preprocessor), ("model", model)])
        pipeline.fit(X_train, y_train)
        pred = pipeline.predict(X_test)
        metrics = {
            "accuracy": round(accuracy_score(y_test, pred), 4),
            "precision": round(precision_score(y_test, pred, zero_division=0), 4),
            "recall": round(recall_score(y_test, pred, zero_division=0), 4),
            "f1_score": round(f1_score(y_test, pred, zero_division=0), 4),
        }
        results[name] = metrics
        if metrics["f1_score"] > best_f1:
            best_name = name
            best_pipeline = pipeline
            best_f1 = metrics["f1_score"]

    joblib.dump(best_pipeline, MODEL_DIR / "recommendation_model.pkl")
    joblib.dump(best_pipeline.named_steps["preprocess"], MODEL_DIR / "scaler.pkl")
    (MODEL_DIR / "model_metrics.json").write_text(json.dumps({"best_model": best_name, "models": results}, indent=2), encoding="utf-8")
    return {"best_model": best_name, "models": results}


def create_charts() -> None:
    analytics = pd.read_csv(DATA_DIR / "tourism_analytics.csv")
    destinations = pd.read_csv(DATA_DIR / "destinations.csv")

    sns.set_theme(style="whitegrid")
    top = analytics.groupby("destination", as_index=False)["visitor_count"].sum().sort_values("visitor_count", ascending=False).head(10)
    plt.figure(figsize=(12, 6))
    sns.barplot(data=top, y="destination", x="visitor_count", palette="viridis")
    plt.title("Most Visited Destinations")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "most_visited_destinations.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 5))
    order = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    trend = analytics.groupby("month", as_index=False)["visitor_count"].sum()
    trend["month"] = pd.Categorical(trend["month"], categories=order, ordered=True)
    trend = trend.sort_values("month")
    sns.lineplot(data=trend, x="month", y="visitor_count", marker="o")
    plt.xticks(rotation=45)
    plt.title("Seasonal Tourism Trends")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "seasonal_tourism_trends.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 7))
    numeric = destinations[["estimated_cost", "avg_rating", "popularity_score", "recommended_label"]]
    sns.heatmap(numeric.corr(), annot=True, cmap="mako")
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "correlation_heatmap.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 5))
    sns.histplot(destinations["estimated_cost"], bins=30, kde=True, color="#0ea5e9")
    plt.title("Destination Estimated Budget Distribution")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "budget_histogram.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 5))
    sns.boxplot(data=analytics, x="season", y="avg_spending", palette="Set2")
    plt.title("Average Tourist Spending by Season")
    plt.tight_layout()
    plt.savefig(CHART_DIR / "spending_boxplot.png", dpi=160)
    plt.close()


if __name__ == "__main__":
    print(json.dumps(train(), indent=2))
    create_charts()
    print("Training completed. Model, scaler, metrics and charts generated.")
''')

write("generate_datasets.py", r'''
"""Regenerates the synthetic 1000+ record tourism datasets.

The repository already includes generated CSV files. This script is intentionally kept
as a reproducibility hook for evaluators. Run from the project root after installing
requirements if you want to regenerate datasets with your own logic.
"""
from pathlib import Path
import runpy

# The build_tourism_system.py script at repository root contains the deterministic
# dataset-generation logic used for this submission.
ROOT_SCRIPT = Path(__file__).resolve().parents[1] / "build_tourism_system.py"
if ROOT_SCRIPT.exists():
    runpy.run_path(str(ROOT_SCRIPT))
else:
    raise SystemExit("Dataset generator source not found. Use the included CSV datasets directly.")
''')

write("static/css/style.css", r'''
:root {
  --ink: #102033;
  --muted: #6b7a90;
  --brand: #0f766e;
  --brand-2: #0284c7;
  --sun: #f59e0b;
  --glass: rgba(255, 255, 255, 0.82);
}
* { box-sizing: border-box; }
body {
  min-height: 100vh;
  color: var(--ink);
  background:
    radial-gradient(circle at 10% 10%, rgba(20,184,166,.18), transparent 28rem),
    radial-gradient(circle at 90% 0%, rgba(14,165,233,.18), transparent 24rem),
    linear-gradient(135deg, #f8fafc 0%, #e0f2fe 50%, #fff7ed 100%);
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}
.navbar { backdrop-filter: blur(16px); background: rgba(255,255,255,.88)!important; }
.hero {
  position: relative; overflow: hidden; border-radius: 2rem; padding: 5rem 2rem;
  background: linear-gradient(135deg, rgba(15,118,110,.95), rgba(2,132,199,.88)), url('../images/hero.svg');
  background-size: cover; color: #fff; box-shadow: 0 30px 80px rgba(15, 23, 42, .20);
}
.hero:after { content: ""; position: absolute; inset: auto -10% -45% 35%; height: 22rem; border-radius: 999px; background: rgba(255,255,255,.14); }
.hero > * { position: relative; z-index: 1; }
.glass-card { background: var(--glass); border: 1px solid rgba(255,255,255,.7); border-radius: 1.35rem; box-shadow: 0 18px 45px rgba(15,23,42,.10); }
.metric-card { border: 0; border-radius: 1.25rem; color: #fff; background: linear-gradient(135deg, #0f766e, #0891b2); box-shadow: 0 16px 38px rgba(2,132,199,.22); }
.section-title { font-weight: 800; letter-spacing: -.03em; }
.badge-soft { background: rgba(14,165,233,.12); color: #075985; border: 1px solid rgba(14,165,233,.22); }
.form-control, .form-select { border-radius: .9rem; padding: .8rem 1rem; border-color: #dbeafe; }
.btn-brand { background: linear-gradient(135deg, var(--brand), var(--brand-2)); border: 0; color: #fff; border-radius: 999px; padding: .75rem 1.35rem; font-weight: 700; }
.btn-brand:hover { color: #fff; filter: brightness(.96); }
.table { overflow: hidden; border-radius: 1rem; }
.chart-box { min-height: 360px; }
.footer { color: var(--muted); }
.route-pill { display: inline-flex; align-items: center; gap: .5rem; padding: .65rem 1rem; background: #fff; border: 1px solid #bae6fd; border-radius: 999px; margin: .25rem; }
.itinerary-line { border-left: 4px solid #0ea5e9; padding-left: 1rem; }
@media (max-width: 768px) { .hero { padding: 3rem 1.25rem; } }
''')

write("static/js/main.js", r'''
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));
  const alerts = document.querySelectorAll('.alert.auto-hide');
  alerts.forEach(alert => setTimeout(() => bootstrap.Alert.getOrCreateInstance(alert).close(), 4500));
});
''')

write("static/images/hero.svg", r'''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600">
  <defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#0f766e"/><stop offset="1" stop-color="#0284c7"/></linearGradient></defs>
  <rect width="1200" height="600" fill="url(#g)"/>
  <circle cx="1040" cy="110" r="70" fill="#fbbf24" opacity=".85"/>
  <path d="M0 430 C210 330 330 480 520 380 C710 280 850 410 1200 300 L1200 600 L0 600 Z" fill="#ffffff" opacity=".22"/>
  <path d="M120 450 l90-150 90 150 Z M245 450 l130-220 130 220 Z M470 450 l100-170 100 170 Z" fill="#083344" opacity=".42"/>
  <path d="M710 410 q105-155 220 0" fill="none" stroke="#ffffff" stroke-width="18" stroke-linecap="round" opacity=".5"/>
</svg>
''')

base_template = r'''
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ title or 'Tourism Analytics System' }}</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
</head>
<body>
<nav class="navbar navbar-expand-lg sticky-top shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold text-success" href="{{ url_for('index') }}">🌍 Tourism Analytics</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto gap-lg-2">
        <li class="nav-item"><a class="nav-link" href="{{ url_for('index') }}">Home</a></li>
        {% if current_user %}
          <li class="nav-item"><a class="nav-link" href="{{ url_for('dashboard') }}">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('recommendation') }}">Destinations</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('hotel') }}">Hotels</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('restaurant') }}">Restaurants</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('analytics') }}">Analytics</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('weather') }}">Weather</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('budget') }}">Budget</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('route_optimizer') }}">Routes</a></li>
          <li class="nav-item"><a class="nav-link" href="{{ url_for('itinerary') }}">Itinerary</a></li>
          <li class="nav-item"><a class="btn btn-sm btn-outline-danger rounded-pill" href="{{ url_for('logout') }}">Logout</a></li>
        {% else %}
          <li class="nav-item"><a class="nav-link" href="{{ url_for('login') }}">Login</a></li>
          <li class="nav-item"><a class="btn btn-sm btn-brand" href="{{ url_for('register') }}">Register</a></li>
        {% endif %}
      </ul>
    </div>
  </div>
</nav>
<main class="container py-4 py-lg-5">
  {% with messages = get_flashed_messages(with_categories=true) %}
    {% if messages %}
      {% for category, message in messages %}
        <div class="alert alert-{{ category }} alert-dismissible fade show auto-hide" role="alert">{{ message }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
      {% endfor %}
    {% endif %}
  {% endwith %}
  {% block content %}{% endblock %}
</main>
<footer class="footer container py-4 text-center small">Final Year Major Project • Data Science + Machine Learning + Flask + SQLite</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="{{ url_for('static', filename='js/main.js') }}"></script>
{% block scripts %}{% endblock %}
</body>
</html>
'''
write("templates/base.html", base_template)

write("templates/index.html", r'''
{% extends 'base.html' %}
{% block content %}
<section class="hero mb-5">
  <div class="row align-items-center g-4">
    <div class="col-lg-7">
      <span class="badge text-bg-warning rounded-pill mb-3">AI + ML Tourism Planning Platform</span>
      <h1 class="display-4 fw-bold">Plan smarter trips with analytics-driven recommendations.</h1>
      <p class="lead mt-3">A complete final-year project combining Flask, SQLite, Bootstrap, machine learning, route optimization, weather intelligence, budgets and personalized itineraries.</p>
      <div class="d-flex flex-wrap gap-3 mt-4">
        <a href="{{ url_for('register') }}" class="btn btn-light btn-lg rounded-pill fw-bold">Start Planning</a>
        <a href="{{ url_for('login') }}" class="btn btn-outline-light btn-lg rounded-pill">Login</a>
      </div>
    </div>
    <div class="col-lg-5">
      <div class="glass-card p-4 text-dark">
        <h5 class="fw-bold">Project Modules</h5>
        <div class="row g-2 small mt-2">
          {% for item in ['Destination ML', 'Hotels', 'Restaurants', 'Weather', 'Budget', 'Routes', 'Analytics', 'Itinerary'] %}
            <div class="col-6"><span class="badge badge-soft rounded-pill w-100 py-2">{{ item }}</span></div>
          {% endfor %}
        </div>
      </div>
    </div>
  </div>
</section>
<section>
  <div class="d-flex justify-content-between align-items-end mb-3">
    <div><p class="text-success fw-semibold mb-1">Popular Destinations</p><h2 class="section-title">Trending places in the dataset</h2></div>
  </div>
  <div class="row g-4">
    {% for d in popular %}
      <div class="col-md-6 col-xl-4"><div class="glass-card p-4 h-100"><div class="d-flex justify-content-between"><h5 class="fw-bold">{{ d.name }}</h5><span class="badge text-bg-success">{{ d.avg_rating }}★</span></div><p class="text-muted mb-2">{{ d.state }} • {{ d.best_season }}</p><p class="small">{{ d.attractions.replace('|', ', ') }}</p><div class="fw-bold text-success">From {{ d.estimated_cost|inr }}</div></div></div>
    {% endfor %}
  </div>
</section>
{% endblock %}
''')

write("templates/register.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row justify-content-center"><div class="col-md-7 col-lg-5"><div class="glass-card p-4 p-lg-5"><h2 class="section-title mb-3">Create account</h2><form method="post"><div class="mb-3"><label class="form-label">Name</label><input class="form-control" name="name" required></div><div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" required></div><div class="mb-4"><label class="form-label">Password</label><input class="form-control" type="password" name="password" minlength="6" required></div><button class="btn btn-brand w-100">Register</button></form><p class="mt-3 small text-center">Already registered? <a href="{{ url_for('login') }}">Login</a></p></div></div></div>
{% endblock %}
''')

write("templates/login.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row justify-content-center"><div class="col-md-7 col-lg-5"><div class="glass-card p-4 p-lg-5"><h2 class="section-title mb-3">Welcome back</h2><form method="post"><div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" required></div><div class="mb-4"><label class="form-label">Password</label><input class="form-control" type="password" name="password" required></div><button class="btn btn-brand w-100">Login</button></form><p class="mt-3 small text-center">New user? <a href="{{ url_for('register') }}">Create account</a></p></div></div></div>
{% endblock %}
''')

write("templates/dashboard.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="mb-4"><p class="text-success fw-semibold mb-1">Dashboard</p><h1 class="section-title">Welcome {{ current_user.name }}</h1></div>
<div class="row g-4 mb-4"><div class="col-md-4"><div class="metric-card p-4"><p class="mb-1">Average Tourist Spending</p><h2>{{ avg_spending|inr }}</h2></div></div><div class="col-md-4"><div class="metric-card p-4"><p class="mb-1">Dataset Size</p><h2>5000+ Rows</h2></div></div><div class="col-md-4"><div class="metric-card p-4"><p class="mb-1">Active Modules</p><h2>10</h2></div></div></div>
<div class="row g-4"><div class="col-lg-7"><div class="glass-card p-4"><h4 class="fw-bold mb-3">Popular Destinations</h4><div class="row g-3">{% for d in popular %}<div class="col-sm-6"><div class="p-3 bg-white rounded-4 h-100"><strong>{{ d.name }}</strong><div class="small text-muted">{{ d.best_season }} • {{ d.avg_rating }}★</div></div></div>{% endfor %}</div></div></div><div class="col-lg-5"><div class="glass-card p-4"><h4 class="fw-bold mb-3">Weather Information</h4>{% for w in weather %}<div class="d-flex justify-content-between border-bottom py-2"><span>{{ w.destination }}</span><strong>{{ w.temperature }}°C • {{ w.condition }}</strong></div>{% endfor %}</div></div></div>
<div class="glass-card p-4 mt-4"><h4 class="fw-bold">Recent Recommendations</h4>{% if history %}<div class="table-responsive"><table class="table table-hover"><thead><tr><th>Date</th><th>Preferences</th><th>Top Results</th></tr></thead><tbody>{% for h in history %}<tr><td>{{ h.created_at }}</td><td><code>{{ h.preference_json }}</code></td><td><code>{{ h.result_json }}</code></td></tr>{% endfor %}</tbody></table></div>{% else %}<p class="text-muted mb-0">No recommendation history yet. Try the destination recommendation module.</p>{% endif %}</div>
{% endblock %}
''')

write("templates/recommendation.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row g-4"><div class="col-lg-4"><div class="glass-card p-4"><h3 class="section-title">Destination Recommendation</h3><form method="post"><label class="form-label mt-3">Budget</label><input class="form-control" type="number" name="budget" value="{{ prefs.budget }}"><label class="form-label mt-3">Travel Type</label><select class="form-select" name="travel_type">{% for t in ['Solo','Family','Couple','Friends'] %}<option {% if prefs.travel_type==t %}selected{% endif %}>{{ t }}</option>{% endfor %}</select><label class="form-label mt-3">Preferred Season</label><select class="form-select" name="season">{% for s in ['Winter','Summer','Monsoon','All Season'] %}<option {% if prefs.season==s %}selected{% endif %}>{{ s }}</option>{% endfor %}</select><label class="form-label mt-3">Preferred Activities</label><div class="row g-2">{% for a in ['Culture','Beaches','Adventure','Food','Nature','Shopping','Spiritual','Photography'] %}<div class="col-6"><label class="small"><input type="checkbox" name="activities" value="{{ a }}"> {{ a }}</label></div>{% endfor %}</div><button class="btn btn-brand w-100 mt-4">Recommend</button></form></div></div><div class="col-lg-8"><div class="row g-3">{% for d in results %}<div class="col-md-6"><div class="glass-card p-4 h-100"><div class="d-flex justify-content-between"><h5 class="fw-bold">{{ d.name }}</h5><span class="badge text-bg-primary">Score {{ d.score }}</span></div><p class="text-muted">{{ d.state }} • {{ d.best_time_to_visit }}</p><p class="small"><strong>Attractions:</strong> {{ d.attractions.replace('|', ', ') }}</p><p class="small"><strong>Activities:</strong> {{ d.top_activities.replace('|', ', ') }}</p><div class="fw-bold text-success">Estimated Cost {{ d.estimated_cost|inr }}</div></div></div>{% else %}<div class="col-12"><div class="glass-card p-5 text-center text-muted">Submit preferences to view recommendations.</div></div>{% endfor %}</div></div></div>
{% endblock %}
''')

write("templates/hotel.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="glass-card p-4 mb-4"><h2 class="section-title">Hotel Recommendation System</h2><form method="post" class="row g-3"><div class="col-md-3"><label class="form-label">City</label><input class="form-control" name="city" placeholder="Jaipur"></div><div class="col-md-3"><label class="form-label">Budget / Night</label><input class="form-control" type="number" name="budget" value="5000"></div><div class="col-md-3"><label class="form-label">Minimum Rating</label><input class="form-control" type="number" step="0.1" name="rating" value="4.0"></div><div class="col-md-3"><label class="form-label">Hotel Type</label><select class="form-select" name="hotel_type">{% for h in hotel_types %}<option>{{ h }}</option>{% endfor %}</select></div><div class="col-12"><button class="btn btn-brand">Find Hotels</button></div></form></div><div class="row g-3">{% for h in hotels %}<div class="col-md-6 col-xl-4"><div class="glass-card p-4 h-100"><h5 class="fw-bold">{{ h.hotel_name }}</h5><p class="text-muted mb-1">{{ h.city }} • {{ h.location }}</p><span class="badge text-bg-success">{{ h.rating }}★</span> <span class="badge badge-soft">{{ h.hotel_type }}</span><div class="fw-bold mt-3">{{ h.price_per_night|inr }} / night</div></div></div>{% endfor %}</div>
{% endblock %}
''')

write("templates/restaurant.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="glass-card p-4 mb-4"><h2 class="section-title">Restaurant Recommendation System</h2><form method="post" class="row g-3"><div class="col-md-4"><label class="form-label">Destination</label><input class="form-control" name="destination" placeholder="Goa"></div><div class="col-md-4"><label class="form-label">Food Preference</label><select class="form-select" name="food_preference">{% for p in preferences %}<option>{{ p }}</option>{% endfor %}</select></div><div class="col-md-4"><label class="form-label">Budget</label><input class="form-control" type="number" name="budget" value="1000"></div><div class="col-12"><button class="btn btn-brand">Find Restaurants</button></div></form></div><div class="row g-3">{% for r in restaurants %}<div class="col-md-6 col-xl-4"><div class="glass-card p-4 h-100"><h5 class="fw-bold">{{ r.restaurant_name }}</h5><p class="text-muted mb-1">{{ r.destination }} • {{ r.cuisine }}</p><span class="badge text-bg-success">{{ r.rating }}★</span> <span class="badge badge-soft">{{ r.food_preference }}</span><div class="fw-bold mt-3">Average Cost {{ r.average_cost|inr }}</div></div></div>{% endfor %}</div>
{% endblock %}
''')

write("templates/analytics.html", r'''
{% extends 'base.html' %}
{% block content %}
<h1 class="section-title mb-4">Tourism Analytics Dashboard</h1>
<div class="row g-4"><div class="col-lg-6"><div class="glass-card p-4 chart-box"><h5>Most Visited Destinations</h5><canvas id="visitedChart"></canvas></div></div><div class="col-lg-6"><div class="glass-card p-4 chart-box"><h5>Average Tourist Spending</h5><canvas id="spendingChart"></canvas></div></div><div class="col-lg-6"><div class="glass-card p-4 chart-box"><h5>Seasonal Tourism Trends</h5><canvas id="trendChart"></canvas></div></div><div class="col-lg-6"><div class="glass-card p-4 chart-box"><h5>Popular Activities</h5><canvas id="activityChart"></canvas></div></div><div class="col-lg-12"><div class="glass-card p-4 chart-box"><h5>Tourist Satisfaction Score</h5><canvas id="satisfactionChart"></canvas></div></div></div>
{% if chart_images %}<h3 class="section-title mt-5">Matplotlib / Seaborn Generated Charts</h3><div class="row g-3">{% for img in chart_images %}<div class="col-md-6"><div class="glass-card p-3"><img class="img-fluid rounded-4" src="{{ url_for('static', filename='charts/' ~ img) }}" alt="{{ img }}"></div></div>{% endfor %}</div>{% endif %}
{% endblock %}
{% block scripts %}<script>const chartData = {{ chart_json|safe }}; const make=(id,type,items,label,color)=>new Chart(document.getElementById(id),{type,data:{labels:items.map(x=>x[0]),datasets:[{label,data:items.map(x=>x[1]),backgroundColor:color,borderColor:color,borderWidth:2,fill:type==='line'}]},options:{responsive:true,maintainAspectRatio:false}});make('visitedChart','bar',chartData.destinations,'Visitors','#0f766e');make('spendingChart','bar',chartData.spending,'Spending','#f59e0b');make('trendChart','line',chartData.trends,'Visitors','#0284c7');make('activityChart','doughnut',chartData.activities,'Activities',['#0f766e','#0284c7','#f59e0b','#ef4444','#8b5cf6','#14b8a6','#84cc16','#f97316']);make('satisfactionChart','bar',chartData.satisfaction,'Score','#22c55e');</script>{% endblock %}
''')

write("templates/weather.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row g-4"><div class="col-lg-4"><div class="glass-card p-4"><h2 class="section-title">Weather Prediction</h2><form method="post"><label class="form-label mt-2">Destination</label><input class="form-control" name="destination" placeholder="Manali" required><button class="btn btn-brand w-100 mt-4">Check Weather</button></form></div></div><div class="col-lg-8">{% if result %}<div class="metric-card p-4 mb-3"><h3>{{ result.destination }}</h3><div class="row text-center"><div class="col"><h2>{{ result.temperature }}°C</h2><p>Temperature</p></div><div class="col"><h2>{{ result.humidity }}%</h2><p>Humidity</p></div><div class="col"><h2>{{ result.condition }}</h2><p>Condition</p></div></div></div><div class="glass-card p-4"><h5>Monthly Samples</h5><table class="table"><thead><tr><th>Month</th><th>Season</th><th>Temperature</th><th>Humidity</th><th>Condition</th></tr></thead><tbody>{% for s in result.samples %}<tr><td>{{ s.month }}</td><td>{{ s.season }}</td><td>{{ s.temperature }}°C</td><td>{{ s.humidity }}%</td><td>{{ s.condition }}</td></tr>{% endfor %}</tbody></table></div>{% else %}<div class="glass-card p-5 text-center text-muted">Enter destination to view predicted weather conditions.</div>{% endif %}</div></div>
{% endblock %}
''')

write("templates/budget.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row g-4"><div class="col-lg-5"><div class="glass-card p-4"><h2 class="section-title">Budget Planner</h2><form method="post"><label class="form-label mt-2">Destination</label><input class="form-control" name="destination" value="Jaipur"><label class="form-label mt-3">Number of Days</label><input class="form-control" type="number" name="days" value="3"><label class="form-label mt-3">Hotel Type</label><select class="form-select" name="hotel_type">{% for h in hotel_types %}<option>{{ h }}</option>{% endfor %}</select><label class="form-label mt-3">Transport Type</label><select class="form-select" name="transport_type">{% for t in transports %}<option>{{ t }}</option>{% endfor %}</select><button class="btn btn-brand w-100 mt-4">Generate Budget</button></form></div></div><div class="col-lg-7">{% if plan %}<div class="glass-card p-4"><h3 class="fw-bold">Budget for {{ plan.destination }} ({{ plan.days }} days)</h3><table class="table mt-3"><tr><th>Accommodation</th><td>{{ plan.accommodation|inr }}</td></tr><tr><th>Food</th><td>{{ plan.food|inr }}</td></tr><tr><th>Travel</th><td>{{ plan.travel|inr }}</td></tr><tr><th>Local Transport & Activities</th><td>{{ plan.local|inr }}</td></tr><tr class="table-success"><th>Total Budget</th><th>{{ plan.total|inr }}</th></tr></table></div>{% else %}<div class="glass-card p-5 text-center text-muted">Submit trip details to generate cost summary.</div>{% endif %}</div></div>
{% endblock %}
''')

write("templates/route.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row g-4"><div class="col-lg-4"><div class="glass-card p-4"><h2 class="section-title">Route Optimization</h2><form method="post"><label class="form-label mt-2">Starting City</label><select class="form-select" name="start">{% for c in cities %}<option>{{ c }}</option>{% endfor %}</select><label class="form-label mt-3">Destination</label><select class="form-select" name="destination">{% for c in cities %}<option>{{ c }}</option>{% endfor %}</select><button class="btn btn-brand w-100 mt-4">Find Shortest Route</button></form></div></div><div class="col-lg-8">{% if result %}<div class="glass-card p-4"><h3 class="fw-bold">Shortest Route</h3><p class="text-muted">Dijkstra graph algorithm output</p><div class="mb-3">{% for c in result.path %}<span class="route-pill">{{ c }}</span>{% if not loop.last %}<span>→</span>{% endif %}{% endfor %}</div><div class="row"><div class="col-md-6"><div class="metric-card p-4"><p>Distance</p><h2>{{ result.distance }} km</h2></div></div><div class="col-md-6"><div class="metric-card p-4"><p>Estimated Travel Time</p><h2>{{ result.time }} hrs</h2></div></div></div></div>{% else %}<div class="glass-card p-5 text-center text-muted">Choose cities to calculate route.</div>{% endif %}</div></div>
{% endblock %}
''')

write("templates/itinerary.html", r'''
{% extends 'base.html' %}
{% block content %}
<div class="row g-4"><div class="col-lg-4"><div class="glass-card p-4"><h2 class="section-title">Personalized Itinerary</h2><form method="post"><label class="form-label mt-2">Destination</label><input class="form-control" name="destination" value="Jaipur"><label class="form-label mt-3">Days</label><input class="form-control" type="number" name="days" value="3" min="1" max="7"><button class="btn btn-brand w-100 mt-4">Generate Itinerary</button></form></div></div><div class="col-lg-8">{% if itinerary %}<div class="glass-card p-4"><h3 class="fw-bold mb-4">Day-wise Plan</h3>{% for day in itinerary %}<div class="itinerary-line mb-4"><h5 class="fw-bold">Day {{ day.day }}</h5><p><strong>Morning:</strong> {{ day.morning }}</p><p><strong>Afternoon:</strong> {{ day.afternoon }}</p><p><strong>Evening:</strong> {{ day.evening }}</p><p><strong>Food Suggestion:</strong> {{ day.food }}</p><p><strong>Hotel Suggestion:</strong> {{ day.hotel }}</p></div>{% endfor %}</div>{% else %}<div class="glass-card p-5 text-center text-muted">Enter destination and days to generate a personalized plan.</div>{% endif %}</div></div>
{% endblock %}
''')

write("templates/error.html", r'''
{% extends 'base.html' %}
{% block content %}<div class="glass-card p-5 text-center"><h1 class="section-title">Oops!</h1><p class="text-muted">{{ message }}</p><a class="btn btn-brand" href="{{ url_for('dashboard') if current_user else url_for('index') }}">Go Back</a></div>{% endblock %}
''')

readme = r'''
# Tourism Analytics System using Data Science, Machine Learning, and Web Development

A professional final-year major project for BCA/B.Tech evaluation. The system helps travelers plan trips intelligently by recommending destinations, hotels, restaurants, routes, budgets, weather insights and personalized day-wise itineraries.

## Tech Stack

- Frontend: HTML5, CSS3, JavaScript, Bootstrap 5
- Backend: Python, Flask
- Database: SQLite
- Data Science / ML: Pandas, NumPy, Scikit-Learn, Matplotlib, Seaborn
- Deployment: Render, Gunicorn

## Core Features

1. User registration, login and logout with password hashing.
2. Authenticated dashboard with popular destinations, weather summary, budget summary and recent recommendation history.
3. ML-based destination recommendation using budget, travel type, season and activities.
4. Hotel recommendation by budget, city, rating and type.
5. Restaurant recommendation by destination, food preference and budget.
6. Tourism analytics dashboard with Chart.js plus Matplotlib/Seaborn chart generation.
7. Weather prediction from dataset records.
8. Budget planner for accommodation, food, travel and local activity costs.
9. Route optimization using Dijkstra shortest path algorithm.
10. Personalized travel itinerary generator.

## Dataset Files

All datasets are stored in `dataset/` and contain 1000+ records each:

- `destinations.csv`
- `hotels.csv`
- `restaurants.csv`
- `weather.csv`
- `tourism_analytics.csv`

## Machine Learning Workflow

`train_model.py` implements:

- Data cleaning and duplicate removal
- Missing value handling
- Feature engineering
- Encoding categorical variables with OneHotEncoder
- Scaling numeric variables with StandardScaler
- EDA charts: heatmap, histogram and boxplot
- Model training: Random Forest, Decision Tree and KNN
- Evaluation: Accuracy, Precision, Recall and F1 Score
- Best model persistence to `models/recommendation_model.pkl`

## Installation

```bash
cd Tourism_Analytics_System
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
python app.py
```

Open: `http://127.0.0.1:5000`

## Default Usage

1. Register a new account.
2. Login.
3. Open Destination Recommendation and submit preferences.
4. Explore hotels, restaurants, analytics, weather, budget, route and itinerary modules.

## Render Deployment

This project includes `Procfile` and `render.yaml`.

Manual Render setup:

- Build command: `pip install -r requirements.txt && python train_model.py`
- Start command: `gunicorn app:app`
- Add environment variable: `SECRET_KEY`

## Folder Structure

```text
Tourism_Analytics_System/
├── app.py
├── requirements.txt
├── README.md
├── generate_datasets.py
├── train_model.py
├── Procfile
├── render.yaml
├── dataset/
├── models/
├── notebooks/
├── static/
├── templates/
├── database/
└── docs/
```

## Project Report Ready Notes

Detailed report and PPT outlines are available in `docs/project_report_outline.md` and `docs/ppt_content_outline.md`.
'''
write("README.md", readme)

write("docs/project_report_outline.md", r'''
# Project Report Outline

1. Title Page
2. Certificate and Declaration
3. Acknowledgement
4. Abstract
5. Introduction
   - Tourism industry challenges
   - Need for intelligent trip planning
6. Objectives
7. Scope of the System
8. Literature Review
9. Existing System and Limitations
10. Proposed System
11. Software and Hardware Requirements
12. System Architecture
13. Database Design
    - users table
    - recommendation_history table
14. Dataset Description
    - destinations, hotels, restaurants, weather, tourism analytics
15. Data Preprocessing
    - cleaning, missing value handling, encoding, scaling
16. Exploratory Data Analysis
    - heatmap, histogram, boxplot, trends
17. Machine Learning Methodology
    - Random Forest, Decision Tree, KNN
18. Model Evaluation
    - accuracy, precision, recall, F1 score
19. Module Implementation
    - authentication, dashboard, recommendations, analytics, weather, route, budget, itinerary
20. Testing
    - unit, integration, UI and error handling test cases
21. Deployment on Render
22. Screenshots
23. Advantages and Limitations
24. Future Enhancements
25. Conclusion
26. References
''')

write("docs/ppt_content_outline.md", r'''
# PPT Content Outline

1. Project Title: Tourism Analytics System
2. Problem Statement
3. Objectives
4. Technology Stack
5. System Architecture Diagram
6. Dataset Overview: 5 CSV files with 1000+ records each
7. Data Preprocessing Steps
8. Exploratory Data Analysis Screens
9. ML Models Used: Random Forest, Decision Tree, KNN
10. Model Comparison Table: Accuracy, Precision, Recall, F1
11. Authentication Module Screenshot
12. Dashboard Screenshot
13. Destination Recommendation Screenshot
14. Hotel and Restaurant Recommendation Screens
15. Analytics Dashboard Screens
16. Weather Prediction Module
17. Budget Planner
18. Route Optimization using Dijkstra
19. Personalized Itinerary Generator
20. Deployment on Render
21. Conclusion
22. Future Scope
23. Thank You
''')

notebook = {
    "cells": [
        {"cell_type": "markdown", "metadata": {}, "source": ["# Tourism Analytics System - Data Science Notebook\n", "This notebook demonstrates dataset loading, EDA, preprocessing, ML training and evaluation.\n"]},
        {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": ["import pandas as pd\n", "import seaborn as sns\n", "import matplotlib.pyplot as plt\n", "destinations = pd.read_csv('../dataset/destinations.csv')\n", "analytics = pd.read_csv('../dataset/tourism_analytics.csv')\n", "destinations.head()\n"]},
        {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": ["destinations.isna().sum()\n", "destinations.describe()\n"]},
        {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": ["sns.heatmap(destinations[['estimated_cost','avg_rating','popularity_score','recommended_label']].corr(), annot=True)\n", "plt.show()\n"]},
        {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": ["%run ../train_model.py\n"]},
    ],
    "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python", "version": "3.x"}},
    "nbformat": 4,
    "nbformat_minor": 5,
}
(ROOT / "notebooks/tourism_analysis.ipynb").write_text(json.dumps(notebook, indent=2), encoding="utf-8")

# Database schema and placeholder model artifacts.
conn = sqlite3.connect(ROOT / "database/tourism.db")
conn.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
conn.execute("CREATE TABLE IF NOT EXISTS recommendation_history (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, preference_json TEXT NOT NULL, result_json TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id))")
conn.commit()
conn.close()

placeholder = {"status": "placeholder", "message": "Install requirements and run python train_model.py to generate the trained scikit-learn artifact."}
(ROOT / "models/recommendation_model.pkl").write_bytes(pickle.dumps(placeholder))
(ROOT / "models/scaler.pkl").write_bytes(pickle.dumps(placeholder))
(ROOT / "models/model_metrics.json").write_text(json.dumps({"best_model": "Run train_model.py", "models": {}}, indent=2), encoding="utf-8")

# Lightweight SVG chart placeholders for immediate presentation before training.
for name, label in {
    "most_visited_destinations.svg": "Most Visited Destinations",
    "seasonal_tourism_trends.svg": "Seasonal Tourism Trends",
    "correlation_heatmap.svg": "Correlation Heatmap",
}.items():
    (ROOT / "static/charts" / name).write_text(f"<svg xmlns='http://www.w3.org/2000/svg' width='900' height='420'><rect width='900' height='420' rx='28' fill='#ecfeff'/><text x='60' y='90' font-size='34' font-family='Arial' font-weight='700' fill='#0f766e'>{label}</text><rect x='70' y='130' width='120' height='220' fill='#0f766e'/><rect x='230' y='180' width='120' height='170' fill='#0284c7'/><rect x='390' y='155' width='120' height='195' fill='#f59e0b'/><rect x='550' y='205' width='120' height='145' fill='#14b8a6'/><rect x='710' y='110' width='120' height='240' fill='#22c55e'/></svg>", encoding="utf-8")

print(f"Generated complete Tourism Analytics System at {ROOT.resolve()}")
